package entity.model;

import java.util.List;

public class Booking {
    private int bookingId;
    private List<Customer> customers; // Changed to List as per Task 10
    private Event event;
    private int numTickets;
    private double totalCost;
    private String bookingDate;

    // Constructors, Getters, Setters
    public Booking() {}
    public Booking(List<Customer> customers, Event event, int numTickets, double totalCost) {
        this.customers = customers;
        this.event = event;
        this.numTickets = numTickets;
        this.totalCost = totalCost;
        this.bookingDate = java.time.LocalDateTime.now().toString();
    }

    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }
    public List<Customer> getCustomers() { return customers; }
    public void setCustomers(List<Customer> customers) { this.customers = customers; }
    public Event getEvent() { return event; }
    public void setEvent(Event event) { this.event = event; }
    public int getNumTickets() { return numTickets; }
    public void setNumTickets(int numTickets) { this.numTickets = numTickets; }
    public double getTotalCost() { return totalCost; }
    public void setTotalCost(double totalCost) { this.totalCost = totalCost; }
    public String getBookingDate() { return bookingDate; }
    public void setBookingDate(String bookingDate) { this.bookingDate = bookingDate; }

    public void displayBookingDetails() {
        System.out.println("Booking ID: " + bookingId + ", Event: " + event.getEventName() + ", Tickets: " + numTickets + ", Cost: " + totalCost + ", Date: " + bookingDate);
        for (Customer c : customers) c.displayCustomerDetails();
    }
}