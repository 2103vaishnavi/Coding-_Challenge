package entity.model;

public class Movie extends Event {
    private String genre;
    private String actorName;
    private String actressName;

    public Movie() {}
    public Movie(String eventName, String eventDate, String eventTime, Venue venue, int totalSeats, double ticketPrice, String genre, String actorName, String actressName) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Movie");
        this.genre = genre;
        this.actorName = actorName;
        this.actressName = actressName;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Movie: " + eventName + ", Date: " + eventDate + ", Time: " + eventTime +
                ", Venue: " + venue.getVenueName() + ", Available Seats: " + availableSeats +
                ", Genre: " + genre + ", Actor: " + actorName + ", Actress: " + actressName);
    }

    // Getters and Setters
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    public String getActorName() { return actorName; }
    public void setActorName(String actorName) { this.actorName = actorName; }
    public String getActressName() { return actressName; }
    public void setActressName(String actressName) { this.actressName = actressName; }
}