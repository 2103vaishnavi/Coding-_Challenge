package entity.model;

public class Concert extends Event {
    private String artist;
    private String type;

    public Concert() {}
    public Concert(String eventName, String eventDate, String eventTime, Venue venue, int totalSeats, double ticketPrice, String artist, String type) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Concert");
        this.artist = artist;
        this.type = type;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Concert: " + eventName + ", Date: " + eventDate + ", Time: " + eventTime +
                ", Venue: " + venue.getVenueName() + ", Available Seats: " + availableSeats +
                ", Artist: " + artist + ", Type: " + type);
    }

    // Getters and Setters
    public String getArtist() { return artist; }
    public void setArtist(String artist) { this.artist = artist; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}