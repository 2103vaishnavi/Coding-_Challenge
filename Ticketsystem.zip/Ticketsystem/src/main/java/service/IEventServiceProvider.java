package service;

import entity.model.Event;
import entity.model.Venue;

public interface IEventServiceProvider {
    Event create_event(String eventName, String date, String time, int totalSeats, double ticketPrice, String eventType, Venue venue);
    Event[] getEventDetails();
    int getAvailableNoOfTickets();
}