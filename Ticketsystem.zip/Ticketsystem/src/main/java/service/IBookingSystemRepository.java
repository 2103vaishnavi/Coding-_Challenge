package service;

import entity.model.Customer;
import entity.model.Event;
import entity.model.Venue;
import exception.EventNotFoundException;
import exception.InvalidBookingIDException;

import java.util.List;

public interface IBookingSystemRepository {
    Event create_event(String eventName, String date, String time, int totalSeats, double ticketPrice, String eventType, Venue venue);
    Event[] getEventDetails();
    int getAvailableNoOfTickets();
    double calculate_booking_cost(int numTickets);
    void book_tickets(String eventName, int numTickets, List<Customer> customers) throws EventNotFoundException; // Updated
    void cancel_booking(int bookingId) throws InvalidBookingIDException;
    void get_booking_details(int bookingId) throws InvalidBookingIDException;
}