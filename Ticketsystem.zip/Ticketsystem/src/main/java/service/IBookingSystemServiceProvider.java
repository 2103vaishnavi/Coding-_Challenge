package service;

import entity.model.Customer;
import entity.model.Event;

import java.util.List;

public interface IBookingSystemServiceProvider {
    double calculate_booking_cost(int numTickets);
    void book_tickets(String eventName, int numTickets, List<Customer> customers);
    void cancel_booking(int bookingId);
    void get_booking_details(int bookingId);
}