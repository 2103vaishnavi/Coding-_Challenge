package app;

import bean.BookingSystemRepositoryImpl;
import entity.model.*;
import exception.EventNotFoundException;
import exception.InvalidBookingIDException;
import service.IBookingSystemRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TicketBookingSystem {
    private static IBookingSystemRepository bookingSystem = new BookingSystemRepositoryImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nTicket Booking System Menu:");
            System.out.println("1. Create Event");
            System.out.println("2. Book Tickets");
            System.out.println("3. Cancel Tickets");
            System.out.println("4. Get Available Seats");
            System.out.println("5. Get Event Details");
            System.out.println("6. Get Booking Details");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        createEvent();
                        break;
                    case 2:
                        bookTickets();
                        break;
                    case 3:
                        cancelTickets();
                        break;
                    case 4:
                        getAvailableSeats();
                        break;
                    case 5:
                        getEventDetails();
                        break;
                    case 6:
                        getBookingDetails();
                        break;
                    case 7:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (EventNotFoundException | InvalidBookingIDException | NullPointerException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }

    private static void createEvent() {
        System.out.print("Enter Event Name: ");
        String eventName = scanner.nextLine();
        System.out.print("Enter Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter Time (HH:MM:SS): ");
        String time = scanner.nextLine();
        System.out.print("Enter Total Seats: ");
        int totalSeats = scanner.nextInt();
        System.out.print("Enter Ticket Price: ");
        double ticketPrice = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Event Type (Movie/Sports/Concert): ");
        String eventType = scanner.nextLine();
        System.out.print("Enter Venue Name: ");
        String venueName = scanner.nextLine();
        System.out.print("Enter Venue Address: ");
        String address = scanner.nextLine();

        Venue venue = new Venue(venueName, address);
        Event event = bookingSystem.create_event(eventName, date, time, totalSeats, ticketPrice, eventType, venue);
        if (event != null) {
            System.out.println("Event created successfully: " + event.getEventName());
        }
    }

    private static void bookTickets() throws EventNotFoundException {
        System.out.print("Enter Event Name: ");
        String eventName = scanner.nextLine();
        System.out.print("Enter Number of Tickets: ");
        int numTickets = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        List<Customer> customers = new ArrayList<>();
        for (int i = 0; i < numTickets; i++) {
            System.out.print("Enter Customer Name for ticket " + (i + 1) + ": ");
            String name = scanner.nextLine();
            customers.add(new Customer(name, name + "@example.com", "1234567890"));
        }

        bookingSystem.book_tickets(eventName, numTickets, customers);
        System.out.println("Tickets booked successfully for " + eventName);
    }

    private static void cancelTickets() throws InvalidBookingIDException {
        System.out.print("Enter Booking ID to cancel: ");
        int bookingId = scanner.nextInt();
        bookingSystem.cancel_booking(bookingId);
        System.out.println("Booking cancelled successfully for ID: " + bookingId);
    }

    private static void getAvailableSeats() {
        System.out.print("Enter Event Name: ");
        String eventName = scanner.nextLine();
        // Placeholder: Implement logic to fetch available seats
        System.out.println("Available Seats for " + eventName + ": " + bookingSystem.getAvailableNoOfTickets());
    }

    private static void getEventDetails() {
        Event[] events = bookingSystem.getEventDetails();
        for (Event e : events) {
            e.displayEventDetails();
        }
    }

    private static void getBookingDetails() throws InvalidBookingIDException {
        System.out.print("Enter Booking ID: ");
        int bookingId = scanner.nextInt();
        bookingSystem.get_booking_details(bookingId);
    }
}