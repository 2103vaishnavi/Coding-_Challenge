package bean;

import entity.model.*;
import exception.EventNotFoundException;
import exception.InvalidBookingIDException;
import service.IBookingSystemRepository;
import util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingSystemRepositoryImpl implements IBookingSystemRepository {
    private static int bookingIdCounter = 1;

    @Override
    public Event create_event(String eventName, String date, String time, int totalSeats, double ticketPrice, String eventType, Venue venue) {
        String venueSql = "INSERT INTO Venue (venue_name, address) VALUES (?, ?) ON DUPLICATE KEY UPDATE venue_id=LAST_INSERT_ID(venue_id)";
        String eventSql = "INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        Connection conn = null;
        try {
            conn = DBUtil.getDBConn();
            conn.setAutoCommit(false); // Start transaction

            // Insert or update Venue
            try (PreparedStatement venueStmt = conn.prepareStatement(venueSql, Statement.RETURN_GENERATED_KEYS)) {
                venueStmt.setString(1, venue.getVenueName());
                venueStmt.setString(2, venue.getAddress());
                venueStmt.executeUpdate();

                ResultSet rs = venueStmt.getGeneratedKeys();
                int venueId = 1; // Default if no new key
                if (rs.next()) {
                    venueId = rs.getInt(1);
                }

                // Insert Event
                try (PreparedStatement eventStmt = conn.prepareStatement(eventSql, Statement.RETURN_GENERATED_KEYS)) {
                    eventStmt.setString(1, eventName);
                    eventStmt.setString(2, date);
                    eventStmt.setString(3, time);
                    eventStmt.setInt(4, venueId);
                    eventStmt.setInt(5, totalSeats);
                    eventStmt.setInt(6, totalSeats); // available_seats starts equal to total_seats
                    eventStmt.setDouble(7, ticketPrice);
                    eventStmt.setString(8, eventType);
                    eventStmt.executeUpdate();

                    rs = eventStmt.getGeneratedKeys();
                    if (rs.next()) {
                        int eventId = rs.getInt(1);
                        Event event = createEventObject(eventName, date, time, venue, totalSeats, ticketPrice, eventType, eventId);
                        conn.commit(); // Commit transaction
                        System.out.println("Event created successfully with ID: " + eventId); // Debug output
                        return event;
                    }
                }
            }
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                    System.out.println("Transaction rolled back due to: " + e.getMessage()); // Debug output
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    private Event createEventObject(String eventName, String date, String time, Venue venue, int totalSeats, double ticketPrice, String eventType, int eventId) {
        switch (eventType.toLowerCase()) {
            case "movie":
                return new Movie(eventName, date, time, venue, totalSeats, ticketPrice, "Action", "Actor1", "Actress1");
            case "concert":
                return new Concert(eventName, date, time, venue, totalSeats, ticketPrice, "Artist1", "Rock");
            case "sports":
                return new Sports(eventName, date, time, venue, totalSeats, ticketPrice, "Cricket", "India vs Pakistan");
            default:
                return null;
        }
    }

    @Override
    public void book_tickets(String eventName, int numTickets, List<Customer> customers) throws EventNotFoundException {
        String selectSql = "SELECT * FROM Event WHERE event_name = ? AND available_seats >= ?";
        String updateSql = "UPDATE Event SET available_seats = available_seats - ? WHERE event_id = ?";
        Connection conn = null;

        try {
            conn = DBUtil.getDBConn();
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement stmt = conn.prepareStatement(selectSql)) {
                stmt.setString(1, eventName);
                stmt.setInt(2, numTickets);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    int eventId = rs.getInt("event_id");
                    int availableSeats = rs.getInt("available_seats");
                    if (availableSeats >= numTickets) {
                        double totalCost = numTickets * rs.getDouble("ticket_price");

                        // Update available seats
                        try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                            updateStmt.setInt(1, numTickets);
                            updateStmt.setInt(2, eventId);
                            int rowsAffected = updateStmt.executeUpdate();
                            if (rowsAffected == 0) {
                                throw new SQLException("Failed to update available seats for event ID: " + eventId);
                            }
                        }

                        // Insert customer and booking
                        int customerId = insertCustomer(customers.get(0), conn); // Assuming one customer for simplicity
                        if (customerId == -1) {
                            throw new SQLException("Failed to insert customer");
                        }
                        insertBooking(customerId, eventId, numTickets, totalCost, conn);

                        conn.commit(); // Commit transaction
                        System.out.println("Tickets booked successfully for event: " + eventName); // Debug output
                    } else {
                        throw new EventNotFoundException("Not enough seats available for " + eventName);
                    }
                } else {
                    throw new EventNotFoundException("Event " + eventName + " not found");
                }
            }
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                    System.out.println("Transaction rolled back due to: " + e.getMessage()); // Debug output
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            throw new EventNotFoundException("Database error while booking tickets: " + e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int insertCustomer(Customer customer, Connection conn) throws SQLException {
        String sql = "INSERT INTO Customer (customer_name, email, phone_number) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE customer_id=customer_id";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, customer.getCustomerName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPhoneNumber());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        }
        return -1;
    }

    private void insertBooking(int customerId, int eventId, int numTickets, double totalCost, Connection conn) throws SQLException {
        String sql = "INSERT INTO Booking (customer_id, event_id, num_tickets, total_cost) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            stmt.setInt(2, eventId);
            stmt.setInt(3, numTickets);
            stmt.setDouble(4, totalCost);
            stmt.executeUpdate();
        }
    }

    @Override
    public Event[] getEventDetails() {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT e.*, v.venue_name, v.address FROM Event e JOIN Venue v ON e.venue_id = v.venue_id";
        try (Connection conn = DBUtil.getDBConn();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Venue venue = new Venue(rs.getString("venue_name"), rs.getString("address"));
                Event event = createEventObject(
                        rs.getString("event_name"), rs.getString("event_date"), rs.getString("event_time"),
                        venue, rs.getInt("total_seats"), rs.getDouble("ticket_price"), rs.getString("event_type"), rs.getInt("event_id")
                );
                if (event != null) {
                    event.setAvailableSeats(rs.getInt("available_seats"));
                    events.add(event);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events.toArray(new Event[0]);
    }

    @Override
    public int getAvailableNoOfTickets() {
        return 0; // Placeholder
    }

    @Override
    public double calculate_booking_cost(int numTickets) {
        return numTickets * 1500.0; // Placeholder
    }

    @Override
    public void cancel_booking(int bookingId) throws InvalidBookingIDException {
        String sql = "SELECT * FROM Booking WHERE booking_id = ?";
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int eventId = rs.getInt("event_id");
                int numTickets = rs.getInt("num_tickets");
                String updateSql = "UPDATE Event SET available_seats = available_seats + ? WHERE event_id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setInt(1, numTickets);
                    updateStmt.setInt(2, eventId);
                    updateStmt.executeUpdate();

                    String deleteSql = "DELETE FROM Booking WHERE booking_id = ?";
                    try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                        deleteStmt.setInt(1, bookingId);
                        deleteStmt.executeUpdate();
                    }
                }
            } else {
                throw new InvalidBookingIDException("Invalid Booking ID: " + bookingId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new InvalidBookingIDException("Database error while cancelling booking ID: " + bookingId);
        }
    }

    @Override
    public void get_booking_details(int bookingId) throws InvalidBookingIDException {
        String sql = "SELECT b.*, e.event_name, c.customer_name FROM Booking b " +
                "JOIN Event e ON b.event_id = e.event_id " +
                "JOIN Customer c ON b.customer_id = c.customer_id " +
                "WHERE b.booking_id = ?";
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Booking ID: " + rs.getInt("booking_id") +
                        ", Event: " + rs.getString("event_name") +
                        ", Customer: " + rs.getString("customer_name") +
                        ", Tickets: " + rs.getInt("num_tickets") +
                        ", Cost: " + rs.getDouble("total_cost") +
                        ", Date: " + rs.getTimestamp("booking_date"));
            } else {
                throw new InvalidBookingIDException("Booking ID " + bookingId + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new InvalidBookingIDException("Database error while fetching booking details for ID: " + bookingId);
        }
    }
}