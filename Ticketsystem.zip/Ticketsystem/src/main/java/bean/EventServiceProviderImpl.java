package bean;

import entity.model.Event;
import entity.model.Venue;
import service.IEventServiceProvider;

public class EventServiceProviderImpl implements IEventServiceProvider {
    @Override
    public Event create_event(String eventName, String date, String time, int totalSeats, double ticketPrice, String eventType, Venue venue) {
        // Placeholder for event creation logic
        return null;
    }

    @Override
    public Event[] getEventDetails() {
        // Placeholder
        return new Event[0];
    }

    @Override
    public int getAvailableNoOfTickets() {
        // Placeholder
        return 0;
    }
}