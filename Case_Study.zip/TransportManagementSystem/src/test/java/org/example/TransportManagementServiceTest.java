package org.example;

import dao.TransportManagementServiceImpl;
import entity.Booking;
import entity.Driver;
import entity.Vehicle;
import exception.BookingNotFoundException;
import exception.VehicleNotFoundException;
import org.junit.Before;
import org.junit.Test;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static org.junit.Assert.*;

public class TransportManagementServiceTest {
    private TransportManagementServiceImpl service;

    @Before
    public void setUp() {
        service = new TransportManagementServiceImpl();
        try (Connection conn = service.getConnection()) {
            Statement stmt = conn.createStatement();
            stmt.execute("TRUNCATE TABLE Bookings");
            stmt.execute("TRUNCATE TABLE Trips");
            stmt.execute("TRUNCATE TABLE Vehicles");
            stmt.executeUpdate("Delete from drivers");

            // Insert initial data
            stmt.execute("INSERT INTO Vehicles (VehicleID, Model, Capacity, Type, Status) VALUES (1, 'Toyota', 40.0, 'Bus', 'Available')");
            stmt.execute("INSERT INTO Drivers (DriverID, Name, LicenseNumber, Status) VALUES (1, 'Suresh More', 'LIC123', 'Available')");
            stmt.execute("INSERT INTO Trips (DriverID, TripID, VehicleID, RouteID, DepartureDate, ArrivalDate, Status, TripType, MaxPassengers) " +
                    "VALUES (1, 1, 1, '2025-04-10 10:00:00', '2025-04-10 12:00:00', 'Scheduled', 'Passenger', 50)");
            // Debug: Check if VehicleID 1 is available
            ResultSet rs = stmt.executeQuery("SELECT Status FROM Vehicles WHERE VehicleID = 1");
            if (rs.next() && !rs.getString("Status").equals("Available")) {
                stmt.execute("UPDATE Vehicles SET Status = 'Available' WHERE VehicleID = 1");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testAddVehicle() {
        Vehicle vehicle = new Vehicle("Honda", 50.0, "Bus", "Available");
        assertTrue(service.addVehicle(vehicle));
        assertTrue(vehicle.getVehicleId() > 0);
    }

    @Test
    public void testUpdateVehicle() throws Exception {
        Vehicle vehicle = new Vehicle("Ford", 30.0, "Van", "Available");
        service.addVehicle(vehicle);
        vehicle.setModel("Suzuki");
        assertTrue(service.updateVehicle(vehicle));
    }

    @Test(expected = VehicleNotFoundException.class)
    public void testUpdateVehicleNotFound() throws Exception {
        Vehicle vehicle = new Vehicle("Test", 20.0, "Truck", "Available");
        vehicle.setVehicleId(999);
        service.updateVehicle(vehicle);
    }

    @Test
    public void testDeleteVehicle() throws Exception {
        Vehicle vehicle = new Vehicle("Ford", 30.0, "Van", "Available");
        service.addVehicle(vehicle);
        assertTrue(service.deleteVehicle(vehicle.getVehicleId()));
    }

    @Test(expected = VehicleNotFoundException.class)
    public void testDeleteVehicleNotFound() throws Exception {
        service.deleteVehicle(999);
    }

    @Test
    public void testScheduleTrip() throws Exception {
        boolean tripScheduled = service.scheduleTrip(1, 1, "2025-04-10 10:00:00", "2025-04-10 12:00:00");
        assertTrue(tripScheduled);
    }

    @Test
    public void testBookTrip() throws Exception {
        boolean booked = service.bookTrip(1, 1, "2025-04-09 09:00:00");
        assertTrue(booked);
    }

    @Test
    public void testBookingSuccess() throws Exception {
        boolean booked = service.bookTrip(1, 1, "2025-04-09 09:00:00");
        assertTrue(booked);
        List<Booking> bookings = service.getBookingsByTrip(1);
        assertFalse(bookings.isEmpty());
        assertEquals("Confirmed", bookings.get(0).getStatus());
    }

    @Test(expected = BookingNotFoundException.class)
    public void testBookingNotFoundException() throws Exception {
        service.cancelBooking(999);
    }

    @Test
    public void testCancelBooking() throws Exception {
        service.bookTrip(1, 1, "2025-04-09 09:00:00");
        List<Booking> bookings = service.getBookingsByTrip(1);
        int bookingId = bookings.get(0).getBookingId();
        assertTrue(service.cancelBooking(bookingId));
    }

    @Test
    public void testDriverMappedToVehicle() throws Exception {
        boolean tripScheduled = service.scheduleTrip(1, 1, "2025-04-10 10:00:00", "2025-04-10 12:00:00");
        assertTrue(tripScheduled);
        boolean driverAllocated = service.allocateDriver(1, 1);
        assertTrue(driverAllocated);
        List<Driver> drivers = service.getAvailableDrivers();
        assertEquals(0, drivers.size());
    }

    @Test
    public void testVehicleAndDriverSetup() throws Exception {
        Vehicle vehicle = new Vehicle("Honda", 50.0, "Bus", "Available");
        assertTrue(service.addVehicle(vehicle));
        assertTrue(vehicle.getVehicleId() > 0);
        List<Driver> drivers = service.getAvailableDrivers();
        assertFalse(drivers.isEmpty());
        assertEquals("Suresh More", drivers.get(0).getName());
    }

    @Test(expected = VehicleNotFoundException.class)
    public void testVehicleNotFoundException() throws Exception {
        Vehicle vehicle = new Vehicle("Test", 20.0, "Truck", "Available");
        vehicle.setVehicleId(999);
        service.updateVehicle(vehicle);
    }
}
