package entity;

public class Booking {
    private int bookingId;
    private int tripId;
    private int passengerId;
    private String bookingDate;
    private String status;

    public Booking() {}
    public Booking(int tripId, int passengerId, String bookingDate, String status) {
        this.tripId = tripId;
        this.passengerId = passengerId;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }
    public int getTripId() { return tripId; }
    public void setTripId(int tripId) { this.tripId = tripId; }
    public int getPassengerId() { return passengerId; }
    public void setPassengerId(int passengerId) { this.passengerId = passengerId; }
    public String getBookingDate() { return bookingDate; }
    public void setBookingDate(String bookingDate) { this.bookingDate = bookingDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}