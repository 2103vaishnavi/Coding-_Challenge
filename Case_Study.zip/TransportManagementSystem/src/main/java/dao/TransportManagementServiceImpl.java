package dao;

import entity.*;
import exception.*;
import util.DBConnUtil;
import util.DBPropertyUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransportManagementServiceImpl implements TransportManagementService {
    public Connection getConnection() { // Changed from private to protected
        String connStr = DBPropertyUtil.getConnectionString("db.properties");
        return DBConnUtil.getConnection(connStr);
    }

    @Override
    public boolean addVehicle(Vehicle vehicle) {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO Vehicles (Model, Capacity, Type, Status) VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, vehicle.getModel());
            stmt.setDouble(2, vehicle.getCapacity());
            stmt.setString(3, vehicle.getType());
            stmt.setString(4, vehicle.getStatus());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) vehicle.setVehicleId(rs.getInt(1));
            }
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateVehicle(Vehicle vehicle) throws VehicleNotFoundException {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE Vehicles SET Model=?, Capacity=?, Type=?, Status=? WHERE VehicleID=?")) {
            stmt.setString(1, vehicle.getModel());
            stmt.setDouble(2, vehicle.getCapacity());
            stmt.setString(3, vehicle.getType());
            stmt.setString(4, vehicle.getStatus());
            stmt.setInt(5, vehicle.getVehicleId());
            int rows = stmt.executeUpdate();
            if (rows == 0) throw new VehicleNotFoundException("Vehicle ID " + vehicle.getVehicleId() + " not found");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Vehicles WHERE VehicleID=?")) {
            stmt.setInt(1, vehicleId);
            int rows = stmt.executeUpdate();
            if (rows == 0) throw new VehicleNotFoundException("Vehicle ID " + vehicleId + " not found");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean scheduleTrip(int vehicleId, int routeId, String departureDate, String arrivalDate) throws VehicleNotFoundException {
        try (Connection conn = getConnection()) {
            PreparedStatement checkStmt = conn.prepareStatement("SELECT Status FROM Vehicles WHERE VehicleID=?");
            checkStmt.setInt(1, vehicleId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next() || !rs.getString("Status").equals("Available")) {
                throw new VehicleNotFoundException("Vehicle ID " + vehicleId + " not available or not found");
            }

            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO Trips (VehicleID, RouteID, DepartureDate, ArrivalDate, Status, TripType, MaxPassengers) " +
                            "VALUES (?, ?, ?, ?, 'Scheduled', 'Passenger', 50)");
            stmt.setInt(1, vehicleId);
            stmt.setInt(2, routeId);
            stmt.setString(3, departureDate);
            stmt.setString(4, arrivalDate);
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                PreparedStatement updateStmt = conn.prepareStatement("UPDATE Vehicles SET Status='On Trip' WHERE VehicleID=?");
                updateStmt.setInt(1, vehicleId);
                updateStmt.executeUpdate();
            }
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean cancelTrip(int tripId) throws Exception {
        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Trips SET Status='Cancelled' WHERE TripID=?");
            stmt.setInt(1, tripId);
            int rows = stmt.executeUpdate();
            if (rows == 0) throw new Exception("Trip ID " + tripId + " not found");

            PreparedStatement vehicleStmt = conn.prepareStatement(
                    "UPDATE Vehicles SET Status='Available' WHERE VehicleID=(SELECT VehicleID FROM Trips WHERE TripID=?)");
            vehicleStmt.setInt(1, tripId);
            vehicleStmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean bookTrip(int tripId, int passengerId, String bookingDate) throws Exception {
        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO Bookings (TripID, PassengerID, BookingDate, Status) VALUES (?, ?, ?, 'Confirmed')");
            stmt.setInt(1, tripId);
            stmt.setInt(2, passengerId);
            stmt.setString(3, bookingDate);
            int rows = stmt.executeUpdate();
            if (rows == 0) throw new Exception("Booking failed for Trip ID " + tripId);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean cancelBooking(int bookingId) throws BookingNotFoundException {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE Bookings SET Status='Cancelled' WHERE BookingID=?")) {
            stmt.setInt(1, bookingId);
            int rows = stmt.executeUpdate();
            if (rows == 0) throw new BookingNotFoundException("Booking ID " + bookingId + " not found");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean allocateDriver(int tripId, int driverId) throws Exception {
        try (Connection conn = getConnection()) {
            PreparedStatement checkStmt = conn.prepareStatement("SELECT Status FROM Drivers WHERE DriverID=?");
            checkStmt.setInt(1, driverId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next() || !rs.getString("Status").equals("Available")) {
                throw new Exception("Driver ID " + driverId + " not available or not found");
            }

            PreparedStatement stmt = conn.prepareStatement("UPDATE Trips SET DriverID=? WHERE TripID=?");
            stmt.setInt(1, driverId);
            stmt.setInt(2, tripId);
            int rows = stmt.executeUpdate();
            if (rows == 0) throw new Exception("Trip ID " + tripId + " not found");

            PreparedStatement driverStmt = conn.prepareStatement("UPDATE Drivers SET Status='Allocated' WHERE DriverID=?");
            driverStmt.setInt(1, driverId);
            driverStmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deallocateDriver(int tripId) throws Exception {
        try (Connection conn = getConnection()) {
            PreparedStatement getDriverStmt = conn.prepareStatement("SELECT DriverID FROM Trips WHERE TripID=?");
            getDriverStmt.setInt(1, tripId);
            ResultSet rs = getDriverStmt.executeQuery();
            if (!rs.next() || rs.getInt("DriverID") == 0) throw new Exception("No driver allocated to Trip ID " + tripId);
            int driverId = rs.getInt("DriverID");

            PreparedStatement stmt = conn.prepareStatement("UPDATE Trips SET DriverID=NULL WHERE TripID=?");
            stmt.setInt(1, tripId);
            stmt.executeUpdate();

            PreparedStatement driverStmt = conn.prepareStatement("UPDATE Drivers SET Status='Available' WHERE DriverID=?");
            driverStmt.setInt(1, driverId);
            driverStmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<entity.Booking> getBookingsByPassenger(int passengerId) throws Exception {
        List<entity.Booking> bookings = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bookings WHERE PassengerID=?")) {
            stmt.setInt(1, passengerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                entity.Booking booking = new entity.Booking();
                booking.setBookingId(rs.getInt("BookingID"));
                booking.setTripId(rs.getInt("TripID"));
                booking.setPassengerId(rs.getInt("PassengerID"));
                booking.setBookingDate(rs.getString("BookingDate"));
                booking.setStatus(rs.getString("Status"));
                bookings.add(booking);
            }
            return bookings;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Error retrieving bookings");
        }
    }

    @Override
    public List<entity.Booking> getBookingsByTrip(int tripId) throws Exception {
        List<entity.Booking> bookings = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bookings WHERE TripID=?")) {
            stmt.setInt(1, tripId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                entity.Booking booking = new entity.Booking();
                booking.setBookingId(rs.getInt("BookingID"));
                booking.setTripId(rs.getInt("TripID"));
                booking.setPassengerId(rs.getInt("PassengerID"));
                booking.setBookingDate(rs.getString("BookingDate"));
                booking.setStatus(rs.getString("Status"));
                bookings.add(booking);
            }
            return bookings;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Error retrieving bookings");
        }
    }

    @Override
    public List<entity.Driver> getAvailableDrivers() throws Exception {
        List<entity.Driver> drivers = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Drivers WHERE Status='Available'")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                entity.Driver driver = new entity.Driver();
                driver.setDriverId(rs.getInt("DriverID"));
                driver.setName(rs.getString("Name"));
                driver.setLicenseNumber(rs.getString("LicenseNumber"));
                driver.setStatus(rs.getString("Status"));
                drivers.add(driver);
            }
            return drivers;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Error retrieving drivers");
        }
    }
}