package dao;

import entity.*;
import exception.*;
import java.util.List;

public interface TransportManagementService {
    boolean addVehicle(Vehicle vehicle);
    boolean updateVehicle(Vehicle vehicle) throws VehicleNotFoundException;
    boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException;
    boolean scheduleTrip(int vehicleId, int routeId, String departureDate, String arrivalDate) throws VehicleNotFoundException;
    boolean cancelTrip(int tripId) throws Exception;
    boolean bookTrip(int tripId, int passengerId, String bookingDate) throws Exception;
    boolean cancelBooking(int bookingId) throws BookingNotFoundException;
    boolean allocateDriver(int tripId, int DriverID) throws Exception;
    boolean deallocateDriver(int tripId) throws Exception;
    List<entity.Booking> getBookingsByPassenger(int passengerId) throws Exception;
    List<entity.Booking> getBookingsByTrip(int tripId) throws Exception;
    List<entity.Driver> getAvailableDrivers() throws Exception;
}