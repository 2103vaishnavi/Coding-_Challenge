package util;

import java.io.FileInputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String propertyFileName) {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream("src/main/resources/" + propertyFileName));
            return props.getProperty("db.url") + "?user=" + props.getProperty("db.username") + "&password=" + props.getProperty("db.password");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}