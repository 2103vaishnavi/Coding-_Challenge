package main;

import dao.TransportManagementService;
import dao.TransportManagementServiceImpl;
import entity.*;
import exception.*;

import java.util.List;
import java.util.Scanner;

public class TransportManagementApp {
    public static void main(String[] args) {
        TransportManagementService service = new TransportManagementServiceImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Transport Management System ===");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Update Vehicle");
            System.out.println("3. Delete Vehicle");
            System.out.println("4. Schedule Trip");
            System.out.println("5. Cancel Trip");
            System.out.println("6. Book Trip");
            System.out.println("7. Cancel Booking");
            System.out.println("8. Allocate Driver");
            System.out.println("9. Deallocate Driver");
            System.out.println("10. Get Bookings by Passenger");
            System.out.println("11. Get Bookings by Trip");
            System.out.println("12. Get Available Drivers");
            System.out.println("13. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Model: ");
                        String model = scanner.nextLine();
                        System.out.print("Capacity: ");
                        double capacity = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.print("Type: ");
                        String type = scanner.nextLine();
                        Vehicle vehicle = new Vehicle(model, capacity, type, "Available");
                        if (service.addVehicle(vehicle)) System.out.println("Vehicle added with ID: " + vehicle.getVehicleId());
                        break;
                    case 2:
                        System.out.print("Vehicle ID: ");
                        int vId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("New Model: ");
                        String newModel = scanner.nextLine();
                        Vehicle vUpdate = new Vehicle(newModel, 50.0, "Bus", "Available");
                        vUpdate.setVehicleId(vId);
                        if (service.updateVehicle(vUpdate)) System.out.println("Vehicle updated!");
                        break;
                    case 3:
                        System.out.print("Vehicle ID: ");
                        int delId = scanner.nextInt();
                        if (service.deleteVehicle(delId)) System.out.println("Vehicle deleted!");
                        break;
                    case 4:
                        System.out.print("Vehicle ID: ");
                        int vehicleId = scanner.nextInt();
                        System.out.print("Route ID: ");
                        int routeId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Departure Date (YYYY-MM-DD HH:MM:SS): ");
                        String depDate = scanner.nextLine();
                        System.out.print("Arrival Date (YYYY-MM-DD HH:MM:SS): ");
                        String arrDate = scanner.nextLine();
                        if (service.scheduleTrip(vehicleId, routeId, depDate, arrDate)) System.out.println("Trip scheduled!");
                        break;
                    case 5:
                        System.out.print("Trip ID: ");
                        int tripId = scanner.nextInt();
                        if (service.cancelTrip(tripId)) System.out.println("Trip cancelled!");
                        break;
                    case 6:
                        System.out.print("Trip ID: ");
                        int tId = scanner.nextInt();
                        System.out.print("Passenger ID: ");
                        int pId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Booking Date (YYYY-MM-DD HH:MM:SS): ");
                        String bookDate = scanner.nextLine();
                        if (service.bookTrip(tId, pId, bookDate)) System.out.println("Trip booked!");
                        break;
                    case 7:
                        System.out.print("Booking ID: ");
                        int bId = scanner.nextInt();
                        if (service.cancelBooking(bId)) System.out.println("Booking cancelled!");
                        break;
                    case 8:
                        System.out.print("Trip ID: ");
                        int tripAlloc = scanner.nextInt();
                        System.out.print("Driver ID: ");
                        int driverId = scanner.nextInt();
                        if (service.allocateDriver(tripAlloc, driverId)) System.out.println("Driver allocated!");
                        break;
                    case 9:
                        System.out.print("Trip ID: ");
                        int tripDealloc = scanner.nextInt();
                        if (service.deallocateDriver(tripDealloc)) System.out.println("Driver deallocated!");
                        break;
                    case 10:
                        System.out.print("Passenger ID: ");
                        int passId = scanner.nextInt();
                        List<entity.Booking> bookingsByPass = service.getBookingsByPassenger(passId);
                        System.out.println("Bookings: " + bookingsByPass);
                        break;
                    case 11:
                        System.out.print("Trip ID: ");
                        int tripBookings = scanner.nextInt();
                        List<entity.Booking> bookingsByTrip = service.getBookingsByTrip(tripBookings);
                        System.out.println("Bookings: " + bookingsByTrip);
                        break;
                    case 12:
                        List<entity.Driver> drivers = service.getAvailableDrivers();
                        System.out.println("Available Drivers: " + drivers);
                        break;
                    case 13:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid option!");
                }
            } catch (VehicleNotFoundException | BookingNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }
}