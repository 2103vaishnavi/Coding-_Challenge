package main;

import dao.IOrderManagementRepository;
import dao.OrderProcessor;
import entity.Product;
import entity.User;
import entity.Electronics;
import entity.Clothing;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    private static IOrderManagementRepository repo = new OrderProcessor();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Order Management System ===");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Orders by User");
            System.out.println("7. Exit");
            System.out.print("Enter Choice ");

            int choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        createUser();
                        break;
                    case 2:
                        createProduct();
                        break;
                    case 3:
                        createOrder();
                        break;
                    case 4:
                        cancelOrder();
                        break;
                    case 5:
                        getAllProducts();
                        break;
                    case 6:
                        getOrderByUser();
                        break;
                    case 7:
                        System.out.println("go away");
                        return;
                    default:
                        System.out.println("wrong choice, bro!");
                }
            } catch (Exception e) {
                System.out.println("Something went wrong: " + e.getMessage());
            }
        }
    }

    private static void createUser() {
        System.out.print("User ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Username: ");
        String name = sc.nextLine();
        System.out.print("Password: ");
        String pass = sc.nextLine();
        System.out.print("Role (Admin/User): ");
        String role = sc.nextLine();

        User user = new User(id, name, pass, role);
        repo.createUser(user);
        System.out.println("User created!");
    }

    private static void createProduct() throws UserNotFoundException {
        System.out.print("Admin ID: ");
        int adminId = sc.nextInt();
        User admin = new User(adminId, "", "", "Admin");

        System.out.print("Product ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Product Name: ");
        String name = sc.nextLine();
        System.out.print("Description: ");
        String desc = sc.nextLine();
        System.out.print("Price: ");
        double price = sc.nextDouble();
        System.out.print("Quantity: ");
        int qty = sc.nextInt();
        sc.nextLine();
        System.out.print("Type (Electronics/Clothing): ");
        String type = sc.nextLine();

        Product p;
        if ("Electronics".equalsIgnoreCase(type)) {
            System.out.print("Brand: ");
            String brand = sc.nextLine();
            System.out.print("Warranty (months): ");
            int warranty = sc.nextInt();
            p = new Electronics(id, name, desc, price, qty, brand, warranty);
        } else {
            System.out.print("Size: ");
            String size = sc.nextLine();
            System.out.print("Color: ");
            String color = sc.nextLine();
            p = new Clothing(id, name, desc, price, qty, size, color);
        }

        repo.createProduct(admin, p);
        System.out.println("Product created!");
    }

    private static void createOrder() throws UserNotFoundException {
        System.out.print("User ID: ");
        int userId = sc.nextInt();
        sc.nextLine();
        User user = new User(userId, "", "", "");

        List<Product> products = new ArrayList<>();
        while (true) {
            System.out.print("Product ID (0 to finish): ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.println("Read ID: " + id); // Debug print
            if (id == 0) break;
            products.add(new Product(id, "", "", 0, 0, ""));
        }

        repo.createOrder(user, products);
        System.out.println("Order Created!");
    }

    private static void cancelOrder() throws UserNotFoundException, OrderNotFoundException {
        System.out.print("User ID: ");
        int userId = sc.nextInt();
        System.out.print("Order ID: ");
        int orderId = sc.nextInt();

        repo.cancelOrder(userId, orderId);
        System.out.println("Order cancel!");
    }

    private static void getAllProducts() {
        List<Product> products = repo.getAllProducts();
        for (Product p : products) {
            System.out.println("ID: " + p.getProductId() + ", Name: " + p.getProductName());
        }
    }

    private static void getOrderByUser() throws UserNotFoundException {
        System.out.print("User ID: ");
        int userId = sc.nextInt();
        User user = new User(userId, "", "", "");

        List<Product> products = repo.getOrderByUser(user);
        for (Product p : products) {
            System.out.println("ID: " + p.getProductId() + ", Name: " + p.getProductName());
        }
    }
}