package dao;

import entity.*;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;
import util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderProcessor implements IOrderManagementRepository {
    @Override
    public void createOrder(User user, List<Product> products) throws UserNotFoundException {
        try (Connection conn = DBConnUtil.getDBConn()) {
            String sql = "SELECT * FROM Users WHERE userId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, user.getUserId());
            if (!ps.executeQuery().next()) {
                createUser(user);
            }

            sql = "INSERT INTO Orders (userId, productId) VALUES (?, ?)";
            ps = conn.prepareStatement(sql);
            for (Product p : products) {
                ps.setInt(1, user.getUserId());
                ps.setInt(2, p.getProductId());
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new UserNotFoundException("Difficulty in making order: " + e.getMessage());
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try (Connection conn = DBConnUtil.getDBConn()) {
            String sql = "DELETE FROM Orders WHERE userId = ? AND orderId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setInt(2, orderId);
            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new OrderNotFoundException("Order not found: " + orderId);
            }
        } catch (SQLException e) {
            throw new UserNotFoundException("Difficult to cancel " + e.getMessage());
        }
    }

    @Override
    public void createProduct(User user, Product product) throws UserNotFoundException {
        try (Connection conn = DBConnUtil.getDBConn()) {
            // Check if the user is an Admin
            String sql = "SELECT * FROM Users WHERE userId = ? AND role = 'Admin'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new UserNotFoundException("Admin not found: " + user.getUserId());
            }

            // Insert into Products table
            sql = "INSERT INTO Products (productId, productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?, ?)";
            //System.out.println("Executing query: " + sql); // Debug print
            ps = conn.prepareStatement(sql);
            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setInt(5, product.getQuantityInStock());
            ps.setString(6, product.getType());
            int rows = ps.executeUpdate();
            System.out.println("Rows inserted in Products: " + rows); // Debug print

            // Handle Electronics product
            if (product instanceof Electronics) {
                Electronics e = (Electronics) product;
                sql = "INSERT INTO Electronics (productId, brand, warrantyPeriod) VALUES (?, ?, ?)";
                System.out.println("Executing query: " + sql); // Debug print
                ps = conn.prepareStatement(sql);
                ps.setInt(1, e.getProductId());
                ps.setString(2, e.getBrand());
                ps.setInt(3, e.getWarrantyPeriod());
                rows = ps.executeUpdate();
                System.out.println("Rows inserted in Electronics: " + rows); // Debug print
            }
            // Handle Clothing product
            else if (product instanceof Clothing) {
                Clothing c = (Clothing) product;
                sql = "INSERT INTO Clothing (productId, size, color) VALUES (?, ?, ?)";
               // System.out.println("Executing query: " + sql); // Debug print
                ps = conn.prepareStatement(sql);
                ps.setInt(1, c.getProductId());
                ps.setString(2, c.getSize());
                ps.setString(3, c.getColor());
                rows = ps.executeUpdate();
                System.out.println("Rows inserted in Clothing: " + rows); // Debug print
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
            throw new UserNotFoundException("difficulty in making product: " + e.getMessage());
        }
    }

    @Override
    public void createUser(User user) {
        try (Connection conn = DBConnUtil.getDBConn()) {
            String sql = "INSERT INTO Users (userId, username, password, role) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("User not found: " + e);
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        try (Connection conn = DBConnUtil.getDBConn()) {
            String sql = "SELECT * FROM Products";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Product p = new Product(rs.getInt("productId"), rs.getString("productName"),
                        rs.getString("description"), rs.getDouble("price"),
                        rs.getInt("quantityInStock"), rs.getString("type"));
                products.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Products not found: " + e);
        }
        return products;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        List<Product> products = new ArrayList<>();
        try (Connection conn = DBConnUtil.getDBConn()) {
            String sql = "SELECT p.* FROM Products p JOIN Orders o ON p.productId = o.productId WHERE o.userId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(rs.getInt("productId"), rs.getString("productName"),
                        rs.getString("description"), rs.getDouble("price"),
                        rs.getInt("quantityInStock"), rs.getString("type"));
                products.add(p);
            }
        } catch (SQLException e) {
            throw new UserNotFoundException("Orders not found: " + e.getMessage());
        }
        return products;
    }
}