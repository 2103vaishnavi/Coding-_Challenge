package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnUtil {
    public static Connection getDBConn() {
        try {
            String connString = DBPropertyUtil.getConnectionString("src/main/resources/db.properties");
            Connection conn = DriverManager.getConnection(connString);
            conn.setAutoCommit(true);
            System.out.println("Connection done: " + conn); // Yeh print hona chahiye
            return conn;
        } catch (Exception e) {
            System.out.println("DB connection not done: " + e);
            return null;
        }
    }
}