package util;

import java.io.FileInputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String fileName) {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream(fileName));
            return props.getProperty("db.url") + "?user=" +
                    props.getProperty("db.username") + "&password=" +
                    props.getProperty("db.password");
        } catch (Exception e) {
            System.out.println("Properties nahi mili: " + e);
            return null;
        }
    }
}